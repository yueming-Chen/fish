source("Main.R")
url_format <<- function(date)
{
  paste("http://waterdata.usgs.gov/nwis/uv?cb_00055=on&cb_00010=on&format=html&site_no=04092750&period=&begin_date=",date,"&end_date=",date,sep="")
}

getData(
  "Indiana_1",
  lat = 41.670584, long = -87.441123,
  start_date=as.Date("2016-01-01"), end_date=as.Date("2016-04-22"),
  file_name="Indiana_1"
)