source("Main.R")
url_format <<- function(date){
  paste("http://waterdata.usgs.gov/mi/nwis/uv?cb_00055=on&cb_00010=on&format=html&site_no=04119400&period=&begin_date=",date,"&end_date=",date,sep="")
}

getData(
  "Michigan_1",
  lat = 43.015901,
  long = -85.957719,
  start_date=as.Date("2016-01-01"), end_date=as.Date("2016-04-22"),
  file_name="Michigan_1"
)