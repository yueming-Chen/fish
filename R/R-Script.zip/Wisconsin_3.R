source("Main.R")
url_format <<- function(date)
{
  paste("http://waterdata.usgs.gov/nwis/uv?cb_00055=on&cb_00010=on&format=html&site_no=040851385&period=&begin_date=",date,"&end_date=",date,sep="")
}

getData(
  "Wisconsin_3",
  lat = 44.528600, long = -88.009989,
  start_date=as.Date("2016-01-01"), end_date=as.Date("2016-04-22"),
  file_name="Wisconsin_3"
)